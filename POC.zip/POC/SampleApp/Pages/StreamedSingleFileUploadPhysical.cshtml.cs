using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SampleApp.Pages
{
    public class StreamedSingleFileUploadPhysicalModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
