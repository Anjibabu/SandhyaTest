using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SampleApp.Pages
{
    public class StreamedSingleFileUploadDbModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
